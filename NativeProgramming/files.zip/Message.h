#pragma once
#include <string>

// [배우는 개념: struct]
// 대화 한 줄(누가 말했는지 + 무슨 내용인지)을 표현하는 최소 단위.
// class 대신 struct를 쓴 이유: 이 구조체는 로직(함수) 없이
// 순수하게 데이터만 담기 때문. C++에서 struct와 class는 기능적으로
// 동일하지만(기본 접근 제어자만 다름), "데이터만 담는 용도"일 때는
// 관례적으로 struct를 사용한다.
struct Message {
    std::string role;    // "user" 또는 "ai" — 누가 말한 메시지인지
    std::string content;  // 실제 대화 내용
};
