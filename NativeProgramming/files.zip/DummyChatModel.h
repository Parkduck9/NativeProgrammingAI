#pragma once
#include <string>

// [배우는 개념: 단일 책임 원칙]
// 이 클래스의 책임은 딱 하나다: "입력을 받아서 응답 문자열을 만든다."
// 입출력(cout, cin)이나 대화 기록 저장은 이 클래스가 하지 않는다.
// 그건 ChatApp의 책임이다. 이렇게 나누면 나중에 이 클래스만
// OllamaChatModel로 통째로 바꿔도 ChatApp 코드는 거의 안 바뀐다.
//
// [설계 노트: 왜 인터페이스(IChatModel)를 안 쓰는가]
// 지금은 구현체가 DummyChatModel 하나뿐이다. 구현체가 하나뿐인데
// 인터페이스부터 만들면, 실제로 얻는 이득 없이 파일 수와 간접 호출만
// 늘어난다(조기 추상화). 2단계에서 OllamaChatModel이 추가되어
// "구현체가 2개 이상"이 되는 시점에, 그때 실제로 필요해진 이유를
// 보면서 인터페이스로 리팩토링하는 것이 더 자연스러운 학습 순서다.
class DummyChatModel {
public:
    // const가 두 번 붙는 이유:
    // 1) 매개변수 앞의 const: input을 복사하지 않고 참조로 받되(&),
    //    함수 안에서 절대 수정하지 않겠다는 약속.
    // 2) 함수 뒤의 const: 이 함수는 DummyChatModel 객체의 멤버 변수를
    //    변경하지 않겠다는 약속. 컴파일러가 이 약속을 강제로 검사해준다.
    std::string getResponse(const std::string& input) const;
};
