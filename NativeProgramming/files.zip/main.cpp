#include "ChatApp.h"

// [배우는 개념: main()의 책임을 최소화하기]
// main()은 "무엇을 어떻게 할지"를 모른다. 그냥 ChatApp을 만들고
// run()을 호출할 뿐이다. 프로그램의 실제 로직은 전부 ChatApp,
// DummyChatModel, Message 안에 있다. 이렇게 나누면 나중에
// 프로그램이 커져도 main.cpp는 거의 안 바뀐다.
int main() {
    ChatApp app;
    app.run();
    return 0;
}
