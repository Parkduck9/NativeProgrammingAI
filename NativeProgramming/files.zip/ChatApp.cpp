#include <iostream>
#include "ChatApp.h"

void ChatApp::run() {
    // [배우는 개념: while 조건식으로 루프 종료하기]
    // break나 return으로 중간에 탈출하는 대신, 조건식 자체가
    // "계속할지 말지"를 표현하도록 만들었다. 매 반복마다 입력을 받고,
    // 그 입력이 종료 명령이면 조건식이 false가 되어 루프가 끝난다.
    std::string input = readUserInput();

    while (!isExitCommand(input)) {
        handleTurn(input);
        input = readUserInput();
    }

    std::cout << "프로그램을 종료합니다.\n";
}

std::string ChatApp::readUserInput() {
    std::cout << "User > ";
    std::string line;
    std::getline(std::cin, line);
    return line;
}

bool ChatApp::isExitCommand(const std::string& input) const {
    return input == "exit";
}

void ChatApp::handleTurn(const std::string& userInput) {
    // 1) AI 응답 생성 — 이 부분만 DummyChatModel의 책임
    std::string aiResponse = model_.getResponse(userInput);

    // 2) 출력 — 화면에 보여주는 건 ChatApp의 책임
    //    (DummyChatModel은 std::cout을 전혀 모른다)
    std::cout << "AI > " << aiResponse << "\n\n";

    // 3) 대화 기록 저장
    // [배우는 개념: vector::push_back]
    // Message{...}처럼 중괄호로 구조체를 즉석에서 만들어(임시 객체)
    // 바로 push_back에 넘길 수 있다.
    history_.push_back(Message{"user", userInput});
    history_.push_back(Message{"ai", aiResponse});
}
