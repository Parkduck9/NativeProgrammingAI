#pragma once
#include <string>
#include <vector>
#include "Message.h"
#include "DummyChatModel.h"

// [배우는 개념: 클래스로 프로그램 흐름 묶기]
// main()에 모든 코드를 다 넣지 않고, "채팅 앱 하나"를 표현하는
// 객체로 묶었다. 이렇게 하면 main()은 "ChatApp을 만들고 실행한다"
// 딱 한 줄짜리 책임만 가지게 된다.
class ChatApp {
public:
    // 프로그램이 끝날 때까지 반복되는 메인 루프.
    // main()에서는 이 함수 하나만 호출하면 된다.
    void run();

private:
    // [배우는 개념: private 멤버 함수로 역할 쪼개기]
    // run()을 한 덩어리로 만들지 않고, "입력 받기" / "응답 만들고
    // 출력하기" / "종료할지 판단하기"로 쪼갰다. 각 함수는 이름만
    // 봐도 뭘 하는지 알 수 있어야 한다(단일 책임).

    // 사용자 입력 한 줄을 받아서 반환한다.
    std::string readUserInput();

    // 사용자 입력을 받아 AI 응답을 만들고 화면에 출력한 뒤,
    // 두 메시지(user, ai)를 모두 대화 기록에 저장한다.
    void handleTurn(const std::string& userInput);

    // "exit"을 입력했는지 판단한다.
    bool isExitCommand(const std::string& input) const;

    // [배우는 개념: vector<Message>]
    // 대화 기록을 순서대로 담는 동적 배열. 크기를 미리 정하지 않아도
    // 대화가 늘어날 때마다 자동으로 커진다. 지금은 저장만 하고
    // 화면에 다시 보여주는 기능(/history 같은)은 아직 만들지 않는다.
    std::vector<Message> history_;

    // [배우는 개념: 멤버로 직접 소유]
    // DummyChatModel을 포인터가 아니라 값으로 직접 들고 있다.
    // ChatApp이 살아있는 동안 model_도 항상 함께 존재하고,
    // ChatApp이 소멸되면 model_도 자동으로 함께 정리된다.
    // 포인터나 unique_ptr이 필요한 경우는 "객체를 나중에 교체해야
    // 할 때"인데, 지금은 그럴 필요가 없으므로 가장 단순한 방법을 쓴다.
    DummyChatModel model_;
};
